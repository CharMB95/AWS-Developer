## Run the API using this URL format:

https://API/STAGE/helloworld?name=NAME&city=CITY

## Or use curl:

curl -v -X POST "API/STAGE/helloworld?name=NAME&city=CITY" -H "content-type: application/json" -H "day: DAY" -d "{ \"time\": \"TIMEOFDAY\" }"